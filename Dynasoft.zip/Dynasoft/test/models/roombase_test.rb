require 'test_helper'

class RoombaseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
