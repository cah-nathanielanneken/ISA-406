require 'test_helper'

class RoombaseControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
