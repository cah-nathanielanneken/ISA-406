class StaticPagesController < ApplicationController
  def invalid_user
  end
end
