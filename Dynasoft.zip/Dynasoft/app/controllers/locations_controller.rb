class LocationsController < ApplicationController
  #before_action :admin_user,     only: [:destroy]

  def index
  end
end
