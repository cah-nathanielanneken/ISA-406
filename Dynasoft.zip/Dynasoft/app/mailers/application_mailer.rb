class ApplicationMailer < ActionMailer::Base
  default from: "noreply@dynasoft.com"
  layout 'mailer'
end
